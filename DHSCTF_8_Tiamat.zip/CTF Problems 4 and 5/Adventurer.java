import DHSChallenge.Tiamat;

public class Adventurer {
 public static void main(String[] args) {
  System.out.println("Salutations, brave hero! The mighty dragon lord Tiamat threatens our lands with the mystical power of a key. You have already travelled through the ancient crypt of the dragonslayers to obtain the enchanted sword capable of slaying Tiamat in only a single blow. But what's this? Tiamat has obtained more armor since she last threatened these realms, and landing a blow is nigh impossible! How can you obtain the key she holds if the odds of slaying her are one in a million? Call Tiamat.attack() to try, and System.out.println(Tiamat.attack()) to see the results.");
final String fail = "Tiamat swiftly deflects the blow. Try again.";
String i = fail;
while (i.equals(fail)) i = Tiamat.attack();
System.out.println(i); }}