// Whoever wrote this code made quite a few mistakes. 10, to be exact. Please give them a hand! I'll get you a key for your troubles.
// Oh, and please don't cheat. There's nothing I can do to stop you, but I kindly request that you actually fix all ten errors.
import DHSChallenge.Key;

publicclass BrokenCode {
	public statc void main(String args) {
		Int c = 4
		if (c = 4) {
			for (int i == 0; i < 5; i++ {
				if (i == 5) {
					System.out.println("Wow, you fixed everything wrong with the code! Here's the key: KEY-" + Key.getKey());
			}
		}
	}
}